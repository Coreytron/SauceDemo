///////////////////////////////
// Generic Utility Functions //
///////////////////////////////

//Click an element on the page
export const clickElement = (element) => {
    cy.get(element).click({ force: true });
}

//Open hamburger navigation menu
const openNavigationMenu = () => {
    clickElement('[id="react-burger-menu-btn"]');
}

//Select an option from the navigation menu
export const selectNavigationOption = (navigationOption) => {
    openNavigationMenu();

    switch (navigationOption) {
        case 'All Items':
            clickElement('[id="inventory_sidebar_link"]');
            break;
        case 'About':
            clickElement('[id="about_sidebar_link"]');
            break;
        case 'Logout':
            clickElement('[id="logout_sidebar_link"]');
            break;
        case 'Reset App Slate':
            clickElement('[id="reset_sidebar_link"]');
            break;
        default:
            //Closes the menu
            clickElement('[id="react-burger-cross-btn"]');
    }
}

//Type text into an input field
export const typeInputText = (inputField, text) => {
    cy.get(inputField).type(text);
}

//Clears an input field on the UI
export const clearInputField = (element) => {
    cy.get(element).clear();
}

//Validates values on the UI
export const validateExpectedValue = (element, expectedValue) => {
    cy.get(element).contains(expectedValue);
}

//Validates elements are visible on the UI
export const validateElementVisible = (element) => {
    cy.get(element).should('be.visible');
}

//Submits a form
export const submitForm = () => {
    cy.get('form').submit();
}

//Validates the site banner value
export const validateBannerValue = (expectedValue) => {
    //The class for the banner is different on the Products page
    if (expectedValue === 'Products') {
        validateExpectedValue('[class="product_label"]', expectedValue);
    } else {
        validateExpectedValue('[class="subheader"]', expectedValue);
    }
}

/////////////////////////////
// Login Utility Functions //
/////////////////////////////

//Login as a specified user
export const userLogin = (username, password) => {
    typeInputText('[id="user-name"]', username);
    typeInputText('[id="password"]', password);
    submitUserCredentials();
}

//Presses the Login button
export const submitUserCredentials = () => {
    clickElement('[id="login-button"]');
}

///////////////////////////////
// Product Utility Functions //
///////////////////////////////

//Selects an item to navigate to Product Details
export const selectInventoryProduct = (productName) => {
    clickElement('[alt="' + productName + '"]');
}

//Validates name, description, price of a product
export const validateProductDetails = (productName, productDescription, productPrice) => {
    validateExpectedValue('[class="inventory_details_name"]', productName);
    validateExpectedValue('[class="inventory_details_desc"]', productDescription);
    validateExpectedValue('[class="inventory_details_price"]', productPrice);
}

////////////////////////////////
// Checkout Utility Functions //
////////////////////////////////

//Currently, this is only adding to the cart from product details - Future work will add logic for adding to cart from Products page
export const addProductToCart = () => {
    cy.get('button').contains('ADD TO CART').click({ force: true });
}

//Clicks the shopping cart icon
export const navigateToShoppingCart = () => {
    clickElement('[data-icon="shopping-cart"]');
}

//Clicks the Checkout button from the Your Cart page
export const navigateToCheckout = () => {
    clickElement('[class="btn_action checkout_button"]');
}

//Inputs personal information for checkout
export const inputPersonalInformation = (firstName, lastName, postalCode) => {
    typeInputText('[id="first-name"]', firstName);
    typeInputText('[id="last-name"]', lastName);
    typeInputText('[id="postal-code"]', postalCode);
}

//Validates quantity and product details during checkout overview
export const validateCheckoutProductDetails = (quantity, productName, productDescription, productPrice) => {
    validateExpectedValue('[class="summary_quantity"]', quantity);
    validateExpectedValue('[class="inventory_item_name"]', productName);
    validateExpectedValue('[class="inventory_item_desc"]', productDescription);
    validateExpectedValue('[class="inventory_item_price"]', productPrice);
}

//Validates payment information during checkout overview
export const validatePaymentInformation = (paymentInfo) => {
    validateExpectedValue('[class="summary_value_label"]', paymentInfo);
}

//Validates shipping information during checkout overview
export const validateShippingInformation = (shippingInfo) => {
    validateExpectedValue('[class="summary_value_label"]', shippingInfo);
}

//Validates item total, tax, and cumulative total during checkout overview
export const validateTaxAndTotals = (itemTotal, tax, total) => {
    validateExpectedValue('[class="summary_subtotal_label"]', itemTotal);
    validateExpectedValue('[class="summary_tax_label"]', tax);
    validateExpectedValue('[class="summary_total_label"]', total);
}

//Submits an order
export const submitOrder = () => {
    clickElement('[class="btn_action cart_button"]');
}

//Validates an order has been submitted
export const validateOrderSubmission = (completeHeader, completeText) => {
    validateExpectedValue('[class="complete-header"]', completeHeader);
    validateExpectedValue('[class="complete-text"]', completeText);
}