import { describe } from "mocha"
import {
    userLogin,
    selectNavigationOption,
    validateExpectedValue,
    validateElementVisible,
    selectInventoryProduct,
    addProductToCart,
} from "../utilities/utility_functions"


describe('select navigation elements and validate results', {

}, () => {

    beforeEach(() => {
        cy.visit(Cypress.env('baseUrl'));

        //Login as the standard_user
        userLogin(Cypress.env('standardUsername'), Cypress.env('loginPassword'));
    })

    it("validates selecting Reset App Slate clears the shopping cart", () => {
        //Add an item to cart
        selectInventoryProduct('Sauce Labs Backpack');
        addProductToCart();

        //Validate cart badge is 1
        validateExpectedValue('[class="fa-layers-counter shopping_cart_badge"]', '1');
        selectNavigationOption('Reset App Slate');

        //Validate cart badge is cleared
        //Cypress doesn't have any great ways to validate an element is no longer visible like Selenium does - Discuss options to proceed with team
    })

    it("validates selecting All Items navigates to the Products page", () => {
        selectNavigationOption('All Items');

        //Validate the banner contains Products
        validateExpectedValue('[class="product_label"]', 'Products');
    })

    it("validates selecting Logout returns to landing page", () => {
        selectNavigationOption('Logout');

        //Validates the Login button is now visible to indicate a successful logout
        validateElementVisible('[id="login-button"]');
    })

    //This test is purposefully last because it navigates to a different site
    it("validates selecting About navigates to the saucelabs.com page", () => {
        selectNavigationOption('About');

        //Validate the current URL is saucelabs.com
        cy.url().should('eq', 'https://saucelabs.com/');
    })

})