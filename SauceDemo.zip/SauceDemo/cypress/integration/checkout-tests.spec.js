import { describe } from "mocha"
import {
    userLogin,
    selectInventoryProduct,
    addProductToCart,
    validateExpectedValue,
    navigateToShoppingCart,
    navigateToCheckout,
    inputPersonalInformation,
    submitForm,
    validateCheckoutProductDetails,
    validateBannerValue,
    validatePaymentInformation,
    validateShippingInformation,
    validateTaxAndTotals,
    submitOrder,
    validateOrderSubmission,
} from "../utilities/utility_functions"


describe('validate overall checkout flow', {

}, () => {

    before(() => {
        cy.visit(Cypress.env('baseUrl'));

        //Login as the standard_user
        userLogin(Cypress.env('standardUsername'), Cypress.env('loginPassword'));
    })

    //TODO: Add future tests for adding/removing items from cart and badge is removed from cart after order submission

    //These tests are validating the overall checkout flow - They must be run in order and currently cannot be run independently
    //Normally I have tests only validating one thing, but for some reason when this first test ends, the user is logged out and the cart is emptied
    //I'm not sure if this is expected behavior or a bug since this is a test site, but to temporarily get around it, I have all validations in one test
    it("validates the checkout flow", () => {
        selectInventoryProduct('Sauce Labs Bike Light');
        addProductToCart();

        //TODO: Determine logout issue described above and extract validations out into their own tests
        //Test #1
        //Validate Add to Cart button changes to Remove and cart badge shows 1
        validateExpectedValue('[class="btn_secondary btn_inventory"]', 'REMOVE');
        validateExpectedValue('[class="fa-layers-counter shopping_cart_badge"]', '1');

        //Test #2
        //Navigate to shopping cart and validate banner contains Your Cart
        navigateToShoppingCart();
        validateBannerValue('Your Cart');

        //Test #3
        //Navigate to checkout and validate banner contains Checkout: Your Information
        navigateToCheckout();
        validateBannerValue('Checkout: Your Information');

        //Test #4
        //Enter personal information, click Continue and validate banner contains Checkout: Overview
        inputPersonalInformation('Test', 'User', '12345');
        submitForm();
        validateBannerValue('Checkout: Overview');

        //Test #5
        //Validate overview data
        validateCheckoutProductDetails('1', 'Sauce Labs Bike Light', 'A red light isn\'t the desired state in testing but it sure helps when riding your bike at night. Water-resistant with 3 lighting modes, 1 AAA battery included.', '9.99');
        validatePaymentInformation('SauceCard #31337');
        validateShippingInformation('FREE PONY EXPRESS DELIVERY!');
        validateTaxAndTotals('9.99', '0.80', '10.79');

        //Test #6
        //Complete the order and validate banner and thanks
        submitOrder();
        validateBannerValue('Finish');
        validateOrderSubmission('THANK YOU FOR YOUR ORDER', 'Your order has been dispatched, and will arrive just as fast as the pony can get there!');
    })

})