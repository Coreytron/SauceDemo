import { describe } from "mocha"
import {
    userLogin,
    validateExpectedValue,
    selectNavigationOption,
    submitUserCredentials,
    clearInputField,
    typeInputText,
    validateBannerValue,
} from "../utilities/utility_functions"


describe('login as specified users and validate results', {

}, () => {

    before(() => {
        cy.visit(Cypress.env('baseUrl'));
    })

    afterEach(() => {
        //Clear username and password fields
        clearInputField('[id="user-name"]');
        clearInputField('[id="password"]');
    })

    it("validates username field is required", () => {
        submitUserCredentials();
        validateExpectedValue('[data-test="error"]', 'Username is required');
    })

    it("validates password field is required", () => {
        typeInputText('[id="user-name"]', 'test');
        submitUserCredentials();
        validateExpectedValue('[data-test="error"]', 'Password is required');
    })

    it("validates error message for invalid username and password credentials", () => {
        userLogin('test', 'test');
        validateExpectedValue('[data-test="error"]', 'Username and password do not match any user in this service');
    })

    it("validates standard_user can successfully login", () => {
        userLogin(Cypress.env('standardUsername'), Cypress.env('loginPassword'));

        //Validate the banner contains Products to indicate a successful login
        validateBannerValue('Products');
        selectNavigationOption('Logout');
    })

    it("validates locked_out_user receives an error message", () => {
        userLogin(Cypress.env('lockedOutUsername'), Cypress.env('loginPassword'));
        validateExpectedValue('[data-test="error"]', 'Sorry, this user has been locked out.');
    })

    it("validates problem_user can login but sees incorrect product pictures", () => {
        userLogin(Cypress.env('problemUsername'), Cypress.env('loginPassword'));

        //Validate the user sees the dog photo instead of the correct product photo
        cy.get('img').should('have.attr', 'src', '/static/media/sl-404.168b1cce.jpg');
        selectNavigationOption('Logout');
    })

    //It appears performance_glitch_user takes 5 seconds to login - validate automation does not break when user experiences latency
    it("validates latency is handled properly when logging in as performance_glitch_user", () => {
        userLogin(Cypress.env('performanceGlitchUsername'), Cypress.env('loginPassword'));

        //Validate the banner contains Products to indicate a successful login
        validateBannerValue('Products');
        selectNavigationOption('Logout');
    })

})