import { describe } from "mocha"
import {
    userLogin,
    selectInventoryProduct,
    validateProductDetails,
} from "../utilities/utility_functions"


describe('validate product details of one item', {

}, () => {

    before(() => {
        cy.visit(Cypress.env('baseUrl'));

        //Login as the standard_user
        userLogin(Cypress.env('standardUsername'), Cypress.env('loginPassword'));
    })

    it("validates product details", () => {
        selectInventoryProduct('Sauce Labs Backpack');
        validateProductDetails('Sauce Labs Backpack', 'carry.allTheThings() with the sleek, streamlined Sly Pack that melds uncompromising style with unequaled laptop and tablet protection.', '29.99');
    })

})