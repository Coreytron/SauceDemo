/////////////////////
// Getting Started //
/////////////////////

1. You will need to download and install node.js: https://nodejs.org/en/download/
2. You will also need git for pushing and pulling code changes: https://git-scm.com/downloads
3. Once this repo is pushed to github, create a new directory for Projects on your local machine
4. Next, navigate to this directory from command line
5. Finally, clone it to your local machine (the path will be provided on github) by running the following command: git clone pathfromsite


///////////////////////////
// Running Cypress Tests //
///////////////////////////

Custom commands have not been setup in the package.json file yet.

Note: The below commands assume you're in the SauceDemo directory

- To run tests from the Cypress GUI, run the following command from command line: npx cypress open
- To run the the whole suite headless, run the following command from command line: npx cypress run
- To run individual test classes, run the following command from command line: npx cypress run --spec "PATH/TO/SPECFILEHERE"

For more information on command line options, please reach out with questions and/or visit the following link: https://docs.cypress.io/guides/guides/command-line.html#Commands 